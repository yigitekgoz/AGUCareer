import 'package:flutter/rendering.dart';


class Radii {
  static const BorderRadiusGeometry k0pxRadius = BorderRadius.all(Radius.circular(0.5));
}