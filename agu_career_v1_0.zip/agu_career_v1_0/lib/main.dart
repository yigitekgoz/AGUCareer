import 'package:agucareerv10/hosgeldin_widget/hosgeldin_widget.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());


class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      home: HosgeldinWidget(),
    );
  }
}